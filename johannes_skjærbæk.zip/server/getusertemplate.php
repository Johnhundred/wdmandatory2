<?php
    $sTemplate = file_get_contents("../templates/user.html");

    echo $sTemplate;
?>