<?php
    $output = file_get_contents("../json/data.json");

    echo $output;
?>