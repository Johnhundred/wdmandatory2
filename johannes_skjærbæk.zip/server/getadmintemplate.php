<?php
    $sTemplate = file_get_contents("../templates/admin.html");

    echo $sTemplate;
?>